Instructions for running sesEXACT on Windows:

sesEXACT requires Qt libraries to run. Two options are available.

a. Use Qt libraries from installation
  This assumes that one has already installed Qt. Then one will need to link Qt libraries to PATH. 
  If one has already done so, they can skip steps 1 through 4. 

  1. First go to the folder where Qt has been installed. There is a folder containing the primary Qt libraries. Select 
     the folder belonging to the MinGW_64 compiler, and then go to the 'bin' folder. Note the location and copy it.
  2. Add the location to your PATH (via System Properties > Advanced > 
     Environment Variables). 
  3. Repeat the steps 1 and 2 for the 'Tools' folder inside the Qt folder.
  4. Run the application from the 'bin' folder. 

b. Use libraries provided
  This is a choice provided if one prefers not to install Qt or not to use the installed version of Qt. 
  Libraries are given in the 'lib' folder.

  1. Copy the 'platforms' folder from the 'lib' folder into the 'bin' folder. 
  2. One can either copy all of the libraries into the 'bin' folder, or add the 'lib' folder into PATH. Either way, the 
     libraries will be recognized.
  3. Run the application.

You will see the PDB 2FR3 automatically loaded when first running. Other PDBs can be loaded in two methods. 

One is by using the File > openPDB on the menu. This should load up the file chooser. Choose the PDB in the folder 
above 'bin' named '1b18FH.pdb'. The PDB 1b18 will be loaded.

One can also load files using the terminal. Go to Windows PowerShell (or the Command Prompt) and type .\surf ..\1b18FH.pdb -
this will load 1b18 through the relative path. Alternatively one could use an absolute path as well.